"""48-question benchmark: 4 concepts x 6 cities x 2 periods, with ground truth
computed from the *committed* definitions."""
from __future__ import annotations

import math

from .agents import Answer, Question
from .concepts import PERIODS, REGISTRY, Evaluator, Scope
from .semantic_layer import SemanticLayer
from .warehouse import CITY_NAMES

PERIOD_TEXT = {"last_month": "last month", "last_week": "last week"}


def build_benchmark(ev: Evaluator, truth_layer: SemanticLayer) -> list[Question]:
    qs = []
    for cname, concept in REGISTRY.items():
        d = truth_layer.get(cname)
        for city in CITY_NAMES:
            for period in ("last_month", "last_week"):
                s = Scope(city, *PERIODS[period])
                qs.append(Question(f"{cname}|{city}|{period}", cname, s, period,
                                   f"What was our {cname.replace('_', ' ')} in {city} {PERIOD_TEXT[period]}?",
                                   ev.value(concept, d.choices, s)))
    return qs


def is_correct(a: Answer, q: Question) -> bool:
    return math.isclose(a.value, q.truth, rel_tol=1e-6, abs_tol=1e-9)


def summarise(answers: list[Answer], questions: list[Question]) -> dict:
    qmap = {q.qid: q for q in questions}
    n = len(answers)
    correct = [is_correct(a, qmap[a.qid]) for a in answers]
    flagged = [a.flagged for a in answers]
    wrong = [not c for c in correct]
    n_wrong, n_flag = sum(wrong), sum(flagged)
    silent = sum(1 for w, f in zip(wrong, flagged) if w and not f)
    flagged_wrong = sum(1 for w, f in zip(wrong, flagged) if w and f)
    return {
        "n": n,
        "accuracy": sum(correct) / n,
        "flag_rate": n_flag / n,
        "silent_error_rate": silent / n,
        "flag_recall_of_errors": (flagged_wrong / n_wrong) if n_wrong else None,
        "flag_precision": (flagged_wrong / n_flag) if n_flag else None,
        "median_abs_rel_error_when_wrong": _med([abs(a.value - qmap[a.qid].truth) / max(abs(qmap[a.qid].truth), 1e-9)
                                                 for a, c in zip(answers, correct) if not c]),
    }


def _med(xs):
    if not xs:
        return None
    xs = sorted(xs)
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else (xs[m - 1] + xs[m]) / 2
