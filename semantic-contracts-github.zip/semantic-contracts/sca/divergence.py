"""Interpretation Divergence Index (IDI).

IDI = (max - min) / |median| over the values a question takes under every
admissible interpretation of its concept. It is 0 when the concept is
unambiguous *for this question*, and large when a silent choice of definition
can move the answer materially.
"""
from __future__ import annotations

from dataclasses import dataclass
from statistics import median

from .concepts import Concept, Evaluator, Scope


@dataclass(frozen=True)
class Spread:
    values: tuple
    lo: float
    hi: float
    med: float
    idi: float
    n_distinct: int


def interpretation_spread(ev: Evaluator, concept: Concept, scope: Scope) -> Spread:
    vals = [ev.value(concept, i, scope) for i in concept.interpretations()]
    lo, hi, med = min(vals), max(vals), median(vals)
    idi = (hi - lo) / max(abs(med), 1e-9)
    return Spread(tuple(vals), lo, hi, med, idi, len({round(v, 6) for v in vals}))


def oat_interpretations(concept: Concept, anchor: dict | None = None) -> list[dict]:
    """One-at-a-time (OAT) neighbourhood of an anchor interpretation: the anchor plus every
    single-axis deviation. Size = 1 + sum_k (|A_k| - 1) instead of prod_k |A_k|."""
    anchor = anchor or concept.naive
    out = [dict(anchor)]
    for k, vals in concept.axes.items():
        out += [{**anchor, k: v} for v in vals if v != anchor[k]]
    return out


def oat_spread(ev: Evaluator, concept: Concept, scope: Scope, anchor: dict | None = None) -> Spread:
    vals = [ev.value(concept, i, scope) for i in oat_interpretations(concept, anchor)]
    lo, hi, med = min(vals), max(vals), median(vals)
    return Spread(tuple(vals), lo, hi, med, (hi - lo) / max(abs(med), 1e-9), len({round(v, 6) for v in vals}))
