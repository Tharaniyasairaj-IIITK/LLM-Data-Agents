"""Semantic layer, definition hashes ("contracts") and the Steward agent."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, replace
from pathlib import Path

import yaml

DEFAULT_YAML = Path(__file__).resolve().parents[1] / "semantic" / "metrics.yaml"


@dataclass(frozen=True)
class Definition:
    concept: str
    version: int
    choices: dict
    description: str = ""
    rationale: str = ""

    @property
    def hash(self) -> str:
        payload = json.dumps({"c": self.concept, "v": self.version, "d": self.choices}, sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()[:12]

    @property
    def ref(self) -> tuple:
        """The contract reference an answer carries: (concept, version, hash)."""
        return (self.concept, self.version, self.hash)


@dataclass(frozen=True)
class SemanticLayer:
    defs: dict = field(default_factory=dict)

    @classmethod
    def load(cls, path: str | Path = DEFAULT_YAML) -> "SemanticLayer":
        raw = yaml.safe_load(Path(path).read_text())
        return cls({n: Definition(n, int(m["version"]), dict(m["definition"]),
                                  m.get("description", ""), m.get("rationale", ""))
                    for n, m in raw["metrics"].items()})

    def get(self, concept: str) -> Definition | None:
        return self.defs.get(concept)

    def restrict(self, names) -> "SemanticLayer":
        return SemanticLayer({n: d for n, d in self.defs.items() if n in set(names)})

    def bump(self, concept: str, changes: dict, rationale: str = "") -> "SemanticLayer":
        old = self.defs[concept]
        new = replace(old, version=old.version + 1, choices={**old.choices, **changes},
                      rationale=rationale or old.rationale)
        return SemanticLayer({**self.defs, concept: new})

    def validate(self, ref: tuple | None) -> bool:
        """Is a contract reference still current? Answers with no contract can never be validated."""
        if ref is None:
            return False
        concept, version, h = ref
        d = self.defs.get(concept)
        return d is not None and d.version == version and d.hash == h


class Steward:
    """The agent that owns the semantic layer and issues commitments on request."""

    def __init__(self, layer: SemanticLayer):
        self.layer = layer
        self.calls = 0

    def clarify(self, concept: str) -> Definition:
        self.calls += 1
        d = self.layer.get(concept)
        if d is None:
            raise KeyError(f"steward has no definition for {concept!r}")
        return d
