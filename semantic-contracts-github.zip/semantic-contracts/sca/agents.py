"""Three analyst policies. They are deliberately *simulated* (no LLM) so the
experiments are deterministic and free; scripts/llm_agent.py runs the same
policies with a real LLM in the loop.

  NaiveAgent            answers with the concept's default ("common-sense") interpretation.
  ContextAgent          uses a committed definition when the semantic layer covers the concept.
  DivergenceAwareAgent  uses a committed definition if present; otherwise measures
                        interpretation divergence and, above threshold tau, flags the
                        answer and (optionally) escalates to the Steward for a commitment.
"""
from __future__ import annotations

from dataclasses import dataclass

from .concepts import REGISTRY, Evaluator, Scope
from .divergence import interpretation_spread
from .semantic_layer import SemanticLayer, Steward


@dataclass(frozen=True)
class Question:
    qid: str
    concept: str
    scope: Scope
    period: str
    text: str
    truth: float


@dataclass(frozen=True)
class Answer:
    qid: str
    policy: str
    value: float
    interpretation: dict
    source: str            # default | semantic_layer | steward | default_flagged | default_low_ambiguity
    flagged: bool = False
    idi: float | None = None
    interval: tuple | None = None
    contract: tuple | None = None


class NaiveAgent:
    name = "naive"

    def answer(self, q: Question, ev: Evaluator) -> Answer:
        c = REGISTRY[q.concept]
        return Answer(q.qid, self.name, ev.value(c, c.naive, q.scope), c.naive, "default")


class ContextAgent:
    def __init__(self, layer: SemanticLayer, name: str = "context"):
        self.layer, self.name = layer, name

    def answer(self, q: Question, ev: Evaluator) -> Answer:
        c = REGISTRY[q.concept]
        d = self.layer.get(q.concept)
        if d is None:
            return Answer(q.qid, self.name, ev.value(c, c.naive, q.scope), c.naive, "default")
        return Answer(q.qid, self.name, ev.value(c, d.choices, q.scope), d.choices,
                      "semantic_layer", contract=d.ref)


class DivergenceAwareAgent:
    def __init__(self, layer: SemanticLayer, steward: Steward | None, tau: float, name: str | None = None):
        self.layer, self.steward, self.tau = layer, steward, tau
        self.name = name or f"divergence(tau={tau:g},{'steward' if steward else 'flag-only'})"
        self._memo: dict = {}      # commitments already obtained from the steward

    def answer(self, q: Question, ev: Evaluator) -> Answer:
        c = REGISTRY[q.concept]
        d = self.layer.get(q.concept) or self._memo.get(q.concept)
        if d is not None:
            return Answer(q.qid, self.name, ev.value(c, d.choices, q.scope), d.choices,
                          "semantic_layer", contract=d.ref)
        sp = interpretation_spread(ev, c, q.scope)
        interval = (sp.lo, sp.hi)
        if sp.idi > self.tau:
            if self.steward is not None:
                d = self.steward.clarify(q.concept)
                self._memo[q.concept] = d
                return Answer(q.qid, self.name, ev.value(c, d.choices, q.scope), d.choices,
                              "steward", flagged=True, idi=sp.idi, interval=interval, contract=d.ref)
            return Answer(q.qid, self.name, ev.value(c, c.naive, q.scope), c.naive,
                          "default_flagged", flagged=True, idi=sp.idi, interval=interval)
        return Answer(q.qid, self.name, ev.value(c, c.naive, q.scope), c.naive,
                      "default_low_ambiguity", flagged=False, idi=sp.idi, interval=interval)
