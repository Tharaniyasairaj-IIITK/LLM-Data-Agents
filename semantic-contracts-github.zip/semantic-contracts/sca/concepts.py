"""Business concepts and their *interpretation axes*.

A concept (e.g. "revenue") is ambiguous along several independent axes (include
GST? subtract promo? what about refunds?). Each axis has a finite set of choices;
the Cartesian product is the *interpretation set*. The committed definition in
semantic/metrics.yaml selects one point in that set. `naive` is the point a
reasonable-but-uninformed analyst (or LLM) tends to pick; for revenue it
reproduces the error observed in the source tutorial (GST and refunds removed,
promo discount forgotten).
"""
from __future__ import annotations

import itertools
import re
from dataclasses import dataclass
from typing import Callable

from .warehouse import CITY_NAMES

TODAY = "2026-10-30"
PERIODS = {
    "last_month": ("2026-09-01", "2026-09-30"),
    "last_week": ("2026-10-19", "2026-10-25"),
    "prior_week": ("2026-10-12", "2026-10-18"),
}


@dataclass(frozen=True)
class Scope:
    city: str
    start: str
    end: str

    def __post_init__(self):
        if self.city not in CITY_NAMES:
            raise ValueError(f"unknown city {self.city!r}")
        for d in (self.start, self.end):
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d):
                raise ValueError(f"bad date {d!r}")


def _where(scope: Scope, city_col: str) -> str:
    return (f"{city_col} = '{scope.city}' AND order_ts >= TIMESTAMP '{scope.start}' "
            f"AND order_ts < TIMESTAMP '{scope.end}' + INTERVAL 1 DAY")


BASE = """
WITH base AS (
  SELECT o.order_id, o.order_ts, o.status, o.cancel_reason, o.amount, o.promo_value,
         rc.city_name AS rest_city, cc.city_name AS cust_city,
         COALESCE(t.gst, 0) AS gst, r.refund_amount AS refund_amount,
         (r.order_id IS NOT NULL) AS refunded
  FROM orders o
  JOIN restaurants rs ON rs.restaurant_id = o.restaurant_id
  JOIN cities rc ON rc.city_id = rs.city_id
  JOIN customers cu ON cu.customer_id = o.customer_id
  JOIN cities cc ON cc.city_id = cu.city_id
  LEFT JOIN order_taxes t ON t.order_id = o.order_id
  LEFT JOIN refunds r ON r.order_id = o.order_id
)
"""


def _orders(i: dict, s: Scope) -> str:
    col = "rest_city" if i["city_attr"] == "restaurant_city" else "cust_city"
    extra = " AND status = 'delivered'" if i["status"] == "delivered_only" else ""
    return BASE + f"SELECT COUNT(*)::DOUBLE FROM base WHERE {_where(s, col)}{extra}"


def _revenue(i: dict, s: Scope) -> str:
    expr = "amount"
    if i["tax"] == "exclude_gst":
        expr += " - gst"
    if i["discount"] == "after_promo":
        expr += " - promo_value"
    if i["refunds"] == "subtract_refund_amount":
        expr = f"({expr}) - COALESCE(refund_amount, 0)"
    elif i["refunds"] == "exclude_refunded_orders":
        expr = f"CASE WHEN refunded THEN 0 ELSE ({expr}) END"
    extra = " AND status = 'delivered'" if i["status"] == "delivered_only" else ""
    return BASE + f"SELECT COALESCE(SUM({expr}), 0)::DOUBLE FROM base WHERE {_where(s, 'rest_city')}{extra}"


def _cancel_rate(i: dict, s: Scope) -> str:
    num = "status = 'cancelled'"
    if i["numerator"] == "exclude_customer_cancelled":
        num += " AND cancel_reason <> 'customer_cancelled'"
    den = "TRUE" if i["denominator"] == "all_orders" else "NOT (status = 'cancelled' AND cancel_reason = 'payment_failed')"
    return (BASE + f"SELECT 100.0 * SUM(CASE WHEN {num} THEN 1 ELSE 0 END) / "
            f"NULLIF(SUM(CASE WHEN {den} THEN 1 ELSE 0 END), 0) FROM base WHERE {_where(s, 'rest_city')}")


def _refund_rate(i: dict, s: Scope) -> str:
    den_f = "status = 'delivered'" if i["denominator"] == "delivered_orders" else "TRUE"
    if i["measure"] == "order_count":
        n, d = "CASE WHEN refunded THEN 1 ELSE 0 END", f"CASE WHEN {den_f} THEN 1 ELSE 0 END"
    else:
        n, d = "COALESCE(refund_amount, 0)", f"CASE WHEN {den_f} THEN amount ELSE 0 END"
    return BASE + f"SELECT 100.0 * SUM({n}) / NULLIF(SUM({d}), 0) FROM base WHERE {_where(s, 'rest_city')}"


@dataclass(frozen=True)
class Concept:
    name: str
    unit: str
    axes: dict
    naive: dict
    build: Callable[[dict, Scope], str]

    def interpretations(self) -> list[dict]:
        keys = list(self.axes)
        return [dict(zip(keys, combo)) for combo in itertools.product(*self.axes.values())]

    def sql(self, interp: dict, scope: Scope) -> str:
        if set(interp) != set(self.axes) or any(interp[k] not in self.axes[k] for k in self.axes):
            raise ValueError(f"invalid interpretation for {self.name}: {interp}")
        return self.build(interp, scope)


REGISTRY: dict[str, Concept] = {c.name: c for c in [
    Concept("orders", "orders",
            {"status": ["all", "delivered_only"], "city_attr": ["restaurant_city", "customer_city"]},
            {"status": "all", "city_attr": "restaurant_city"}, _orders),
    Concept("revenue", "INR",
            {"status": ["delivered_only", "all"], "tax": ["exclude_gst", "include_gst"],
             "discount": ["after_promo", "before_promo"],
             "refunds": ["exclude_refunded_orders", "subtract_refund_amount", "ignore"]},
            {"status": "delivered_only", "tax": "exclude_gst", "discount": "before_promo",
             "refunds": "subtract_refund_amount"}, _revenue),
    Concept("cancel_rate", "%",
            {"numerator": ["exclude_customer_cancelled", "all_cancellations"],
             "denominator": ["all_orders", "exclude_payment_failed"]},
            {"numerator": "all_cancellations", "denominator": "all_orders"}, _cancel_rate),
    Concept("refund_rate", "%",
            {"denominator": ["delivered_orders", "all_orders"], "measure": ["order_count", "amount"]},
            {"denominator": "all_orders", "measure": "order_count"}, _refund_rate),
]}


class Evaluator:
    """Runs concept SQL against DuckDB with memoisation."""

    def __init__(self, con):
        self.con = con
        self._cache: dict = {}
        self.queries_run = 0

    def value(self, concept: Concept, interp: dict, scope: Scope) -> float:
        key = (concept.name, tuple(sorted(interp.items())), scope)
        if key not in self._cache:
            v = self.con.execute(concept.sql(interp, scope)).fetchone()[0]
            self._cache[key] = float("nan") if v is None else float(v)
            self.queries_run += 1
        return self._cache[key]
