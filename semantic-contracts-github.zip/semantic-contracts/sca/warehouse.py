"""Synthetic food-delivery warehouse (DuckDB).

Mirrors the six-table warehouse from the source tutorial: cities, restaurants,
customers, orders, order_taxes, refunds. Data are fake but seeded, so every run
is reproducible. A Mumbai "rain week" (2026-10-19..25) is injected: demand dips
slightly while cancellations for `no_rider_available` spike.
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

START, END = date(2026, 4, 1), date(2026, 10, 30)
RAIN_START, RAIN_END = date(2026, 10, 19), date(2026, 10, 25)

CITY_ROWS = [
    ("Mumbai", "Maharashtra", 0.26),
    ("Bengaluru", "Karnataka", 0.22),
    ("Delhi", "Delhi", 0.20),
    ("Pune", "Maharashtra", 0.12),
    ("Hyderabad", "Telangana", 0.12),
    ("Chennai", "Tamil Nadu", 0.08),
]
CITY_NAMES = [c[0] for c in CITY_ROWS]
CUISINES = ["North Indian", "South Indian", "Biryani", "Chinese", "Pizza", "Burgers", "Desserts", "Healthy"]
REASONS = np.array(["restaurant_closed", "no_rider_available", "customer_cancelled", "payment_failed"])


def build(path: str | Path, seed: int = 7, n_orders: int = 170_000,
          n_restaurants: int = 240, n_customers: int = 16_000) -> Path:
    rng = np.random.default_rng(seed)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()

    shares = np.array([c[2] for c in CITY_ROWS])
    shares = shares / shares.sum()
    ids6 = np.arange(1, 7)

    cities = pd.DataFrame({"city_id": ids6, "city_name": CITY_NAMES, "state": [c[1] for c in CITY_ROWS]})
    rest_city = np.concatenate([ids6, rng.choice(ids6, size=n_restaurants - 6, p=shares)])
    restaurants = pd.DataFrame({
        "restaurant_id": np.arange(1, n_restaurants + 1),
        "restaurant_name": [f"Restaurant {i}" for i in range(1, n_restaurants + 1)],
        "city_id": rest_city,
        "cuisine": rng.choice(CUISINES, size=n_restaurants),
    })
    cust_city = np.concatenate([ids6, rng.choice(ids6, size=n_customers - 6, p=shares)])
    customers = pd.DataFrame({
        "customer_id": np.arange(1, n_customers + 1),
        "city_id": cust_city,
        "signup_date": pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.integers(0, 640, n_customers), "D"),
    })

    # ---- order volume per (day, city) ----
    days = pd.date_range(START, END, freq="D")
    nd = len(days)
    dow = np.array([1.0, 0.95, 0.95, 1.0, 1.15, 1.3, 1.25])
    trend = np.linspace(0.8, 1.2, nd)
    lam = np.outer(dow[days.dayofweek] * trend, shares)
    rain_day = np.asarray((days >= pd.Timestamp(RAIN_START)) & (days <= pd.Timestamp(RAIN_END)))
    lam[rain_day, 0] *= 0.94
    lam *= n_orders / lam.sum()
    counts = rng.poisson(lam)

    d_idx, c_idx = np.nonzero(counts)
    rep = counts[d_idx, c_idx]
    d_idx, c_idx = np.repeat(d_idx, rep), np.repeat(c_idx, rep)
    n = len(d_idx)

    hp = np.full(24, 0.2); hp[12:15] += 2.0; hp[19:23] += 3.0; hp[0:7] = 0.03
    hp /= hp.sum()
    ts = (pd.to_datetime(days.values[d_idx])
          + pd.to_timedelta(rng.choice(24, size=n, p=hp), "h")
          + pd.to_timedelta(rng.integers(0, 3600, n), "s"))

    rest_ids = np.empty(n, dtype=int)
    cust_ids = np.empty(n, dtype=int)
    cust_k = np.where(rng.random(n) < 0.97, c_idx, rng.integers(0, 6, n))
    for k in range(6):
        pool_r = restaurants.restaurant_id.values[restaurants.city_id.values == k + 1]
        pool_c = customers.customer_id.values[customers.city_id.values == k + 1]
        m = c_idx == k
        rest_ids[m] = rng.choice(pool_r, size=m.sum())
        m2 = cust_k == k
        cust_ids[m2] = rng.choice(pool_c, size=m2.sum())

    amount = np.round(np.exp(rng.normal(5.95, 0.45, n)), 2)
    has_promo = rng.random(n) < 0.35
    promo = np.where(has_promo, np.round(np.minimum(amount * rng.uniform(0.1, 0.3, n), 150), 2), 0.0)

    rain_order = (c_idx == 0) & rain_day[d_idx]
    cancelled = rng.random(n) < np.where(rain_order, 0.30, 0.09)
    r_norm = rng.choice(4, size=n, p=[0.30, 0.15, 0.40, 0.15])
    r_rain = rng.choice(4, size=n, p=[0.08, 0.75, 0.10, 0.07])
    reason = np.where(cancelled, REASONS[np.where(rain_order, r_rain, r_norm)], None)
    status = np.where(cancelled, "cancelled", "delivered")
    payment = rng.choice(["UPI", "card", "cod"], size=n, p=[0.60, 0.25, 0.15])
    frac = rng.choice([1.0, 0.5], size=n, p=[0.6, 0.4])
    refund_draw = rng.random(n)
    refund_delay = rng.integers(1, 72, n)

    orders = pd.DataFrame({
        "customer_id": cust_ids, "restaurant_id": rest_ids, "order_ts": ts,
        "status": status, "cancel_reason": reason, "amount": amount,
        "promo_value": promo, "payment_method": payment,
        "_frac": frac, "_rdraw": refund_draw, "_rdelay": refund_delay,
    }).sort_values("order_ts").reset_index(drop=True)
    orders.insert(0, "order_id", np.arange(1, n + 1))

    net = orders["amount"] - orders["promo_value"]
    order_taxes = pd.DataFrame({"order_id": orders["order_id"], "gst": np.round(net * 0.05, 2)})
    refunded = (orders["status"] == "delivered") & (orders["_rdraw"] < 0.04)
    refunds = pd.DataFrame({
        "order_id": orders.loc[refunded, "order_id"].to_numpy(),
        "refund_amount": np.round(net[refunded] * orders.loc[refunded, "_frac"], 2).to_numpy(),
        "refunded_at": (orders.loc[refunded, "order_ts"]
                        + pd.to_timedelta(orders.loc[refunded, "_rdelay"], "h")).to_numpy(),
    })
    orders = orders.drop(columns=["_frac", "_rdraw", "_rdelay"])

    con = duckdb.connect(str(path))
    for name, df in dict(cities=cities, restaurants=restaurants, customers=customers,
                         orders=orders, order_taxes=order_taxes, refunds=refunds).items():
        con.register("tmp_df", df)
        con.execute(f"CREATE TABLE {name} AS SELECT * FROM tmp_df")
        con.unregister("tmp_df")
    con.close()
    return path


def connect(path: str | Path, read_only: bool = True) -> duckdb.DuckDBPyConnection:
    return duckdb.connect(str(path), read_only=read_only)
