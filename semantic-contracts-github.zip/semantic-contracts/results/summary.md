# Experiment summary

48 questions; interpretation-set sizes: {'orders': 4, 'revenue': 24, 'cancel_rate': 4, 'refund_rate': 4}

## E0 concept ambiguity

| concept | mean IDI | naive mean abs rel err | naive == committed |
|---|---|---|---|
| orders | 0.127 | 0.000 | True |
| revenue | 0.276 | 0.085 | False |
| cancel_rate | 0.501 | 0.659 | False |
| refund_rate | 0.407 | 0.106 | False |

## E1 policies

| policy | accuracy | flag rate | silent error | steward calls |
|---|---|---|---|---|
| naive | 0.250 | 0.000 | 0.750 | - |
| context_full | 1.000 | 0.000 | 0.000 | - |
| divergence_flag_only_tau0.01 | 0.250 | 1.000 | 0.000 | - |
| divergence_steward_tau0.01 | 1.000 | 0.083 | 0.000 | 4 |
| divergence_flag_only_tau0.05 | 0.250 | 1.000 | 0.000 | - |
| divergence_steward_tau0.05 | 1.000 | 0.083 | 0.000 | 4 |
| divergence_flag_only_tau0.1 | 0.250 | 0.958 | 0.000 | - |
| divergence_steward_tau0.1 | 1.000 | 0.083 | 0.000 | 4 |
| divergence_flag_only_tau0.25 | 0.250 | 0.688 | 0.083 | - |
| divergence_steward_tau0.25 | 1.000 | 0.083 | 0.000 | 4 |
| divergence_flag_only_tau0.5 | 0.250 | 0.229 | 0.521 | - |
| divergence_steward_tau0.5 | 0.917 | 0.062 | 0.083 | 3 |
| divergence_flag_only_tau1 | 0.250 | 0.000 | 0.750 | - |
| divergence_steward_tau1 | 0.250 | 0.000 | 0.750 | 0 |

## E2 partial coverage (tau=0.05)

| concepts covered | context silent err | divergence silent err | steward calls |
|---|---|---|---|
| 0/4 | 0.750 | 0.000 | 4.00 |
| 1/4 | 0.562 | 0.000 | 3.00 |
| 2/4 | 0.375 | 0.000 | 2.00 |
| 3/4 | 0.188 | 0.000 | 1.00 |
| 4/4 | 0.000 | 0.000 | 0.00 |

## E4 OAT estimator

evaluations full={'orders': 4, 'revenue': 24, 'cancel_rate': 4, 'refund_rate': 4} oat={'orders': 3, 'revenue': 6, 'cancel_rate': 3, 'refund_rate': 3}; mean range ratio=0.908 (min 0.633); flag agreement={'tau0.05': {'agreement': 1.0, 'missed_by_oat': 0}, 'tau0.1': {'agreement': 0.8958333333333334, 'missed_by_oat': 5}, 'tau0.25': {'agreement': 0.8125, 'missed_by_oat': 9}}

## E3 drift

revenue v1 `d1f4f211eb01` -> v2 `93fedcf953aa`; stale answers detected with contracts: 6/6, without: 0/6; mean |change| = 7.655%
