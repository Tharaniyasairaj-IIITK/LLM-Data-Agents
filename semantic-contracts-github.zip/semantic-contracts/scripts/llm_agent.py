"""OPTIONAL live-LLM version of the three policies (requires ANTHROPIC_API_KEY).

    python scripts/llm_agent.py --mode chatbot    "Why did our orders drop in Mumbai last week?"
    python scripts/llm_agent.py --mode agent      "What was our revenue in Mumbai last month?"
    python scripts/llm_agent.py --mode context    "What was our revenue in Mumbai last month?"
    python scripts/llm_agent.py --mode divergence "What was our revenue in Mumbai last month?"

chatbot    : no tools (the tutorial's first baseline)
agent      : list_tables / describe_table / run_sql
context    : agent + get_metric_definition (reads semantic/metrics.yaml)
divergence : agent + interpretation_spread; instructed to flag when the spread is large

NOTE: this script is provided for the live demo; it was not used to produce the
numbers in the paper (those come from the deterministic simulated policies).
"""
import argparse, json, os, re

import _path  # noqa: F401
from sca.concepts import REGISTRY, TODAY, Evaluator, Scope
from sca.divergence import interpretation_spread
from sca.semantic_layer import SemanticLayer
from sca.warehouse import connect

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")
ap = argparse.ArgumentParser()
ap.add_argument("question"); ap.add_argument("--mode", choices=["chatbot", "agent", "context", "divergence"], default="agent")
ap.add_argument("--tau", type=float, default=0.05); ap.add_argument("--max-turns", type=int, default=15)
args = ap.parse_args()

import anthropic
client = anthropic.Anthropic()
con = connect(_path.DB); ev = Evaluator(con); layer = SemanticLayer.load()

TOOLS = [
    {"name": "list_tables", "description": "List warehouse tables.", "input_schema": {"type": "object", "properties": {}}},
    {"name": "describe_table", "description": "Columns, types and 3 sample rows of a table.",
     "input_schema": {"type": "object", "properties": {"table": {"type": "string"}}, "required": ["table"]}},
    {"name": "run_sql", "description": "Run a read-only DuckDB SELECT (max 50 rows returned).",
     "input_schema": {"type": "object", "properties": {"sql": {"type": "string"}}, "required": ["sql"]}},
]
if args.mode == "context":
    TOOLS.append({"name": "get_metric_definition", "description": "Committed business definition of a metric: " + ", ".join(REGISTRY),
                  "input_schema": {"type": "object", "properties": {"metric": {"type": "string"}}, "required": ["metric"]}})
if args.mode == "divergence":
    TOOLS.append({"name": "interpretation_spread",
                  "description": "Evaluate a business metric under every admissible interpretation. Returns min, max, median and "
                                 "relative spread (IDI). Metrics: " + ", ".join(REGISTRY),
                  "input_schema": {"type": "object", "properties": {"metric": {"type": "string"}, "city": {"type": "string"},
                                   "start": {"type": "string"}, "end": {"type": "string"}}, "required": ["metric", "city", "start", "end"]}})

SYSTEM = (f"You are a data analyst at a food-delivery company in India. Today is {TODAY}. Cities: Mumbai, Bengaluru, Delhi, Pune, "
          "Hyderabad, Chennai. Plan, inspect tables, write SQL, run it, sanity-check, then answer concisely.")
if args.mode == "context":
    SYSTEM += " Before computing any business metric, call get_metric_definition and follow it exactly."
if args.mode == "divergence":
    SYSTEM += (f" For any business metric (orders, revenue, cancel_rate, refund_rate), call interpretation_spread. If the relative "
               f"spread (IDI) exceeds {args.tau}, do NOT give a single number: report the range, explain which definitional "
               "choices drive it, and ask which definition to use.")


def tool(name, a):
    try:
        if name == "list_tables":
            return "\n".join(r[0] for r in con.execute("SHOW TABLES").fetchall())
        if name == "describe_table":
            t = re.sub(r"[^a-z_]", "", a["table"])
            cols = con.execute(f"DESCRIBE {t}").fetchall()
            rows = con.execute(f"SELECT * FROM {t} LIMIT 3").fetchall()
            return json.dumps({"columns": [(c[0], c[1]) for c in cols], "sample": rows}, default=str)
        if name == "run_sql":
            sql = a["sql"].strip().rstrip(";")
            if not re.match(r"(?is)^(select|with)\b", sql) or re.search(r"(?i)\b(insert|update|delete|drop|alter|create|attach|copy)\b", sql):
                return "error: only read-only SELECT/WITH allowed"
            return json.dumps(con.execute(sql).fetchmany(50), default=str)
        if name == "get_metric_definition":
            d = layer.get(a["metric"]); return json.dumps({"version": d.version, "description": d.description, "rationale": d.rationale})
        if name == "interpretation_spread":
            sp = interpretation_spread(ev, REGISTRY[a["metric"]], Scope(a["city"], a["start"], a["end"]))
            return json.dumps({"min": sp.lo, "max": sp.hi, "median": sp.med, "idi": sp.idi, "n_interpretations": len(sp.values)})
    except Exception as e:  # surface errors to the model so it can retry
        return f"error: {e}"
    return "error: unknown tool"


msgs = [{"role": "user", "content": args.question}]
for _ in range(args.max_turns):
    kw = {"tools": TOOLS} if args.mode != "chatbot" else {}
    r = client.messages.create(model=MODEL, max_tokens=2000, system=SYSTEM + (" Answer in one short paragraph." if args.mode == "chatbot" else ""),
                               messages=msgs, **kw)
    msgs.append({"role": "assistant", "content": r.content})
    uses = [b for b in r.content if b.type == "tool_use"]
    for b in r.content:
        if b.type == "text" and b.text.strip():
            print(b.text)
    if r.stop_reason != "tool_use" or not uses:
        break
    results = []
    for u in uses:
        print(f"  [tool] {u.name} {json.dumps(u.input)[:120]}")
        results.append({"type": "tool_result", "tool_use_id": u.id, "content": tool(u.name, u.input)})
    msgs.append({"role": "user", "content": results})
