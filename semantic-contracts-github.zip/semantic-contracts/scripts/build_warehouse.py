"""Build the synthetic DuckDB warehouse:  python scripts/build_warehouse.py [--seed 7]"""
import argparse
import _path  # noqa: F401
from sca.warehouse import build, connect

p = argparse.ArgumentParser()
p.add_argument("--seed", type=int, default=7)
p.add_argument("--orders", type=int, default=170_000)
a = p.parse_args()
path = build(_path.DB, seed=a.seed, n_orders=a.orders)
con = connect(path)
for t in ["cities", "restaurants", "customers", "orders", "order_taxes", "refunds"]:
    print(f"{t:12s} {con.execute(f'select count(*) from {t}').fetchone()[0]:>9,} rows")
print(f"-> {path}")
