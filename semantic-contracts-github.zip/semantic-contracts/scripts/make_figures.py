"""Figures for the paper:  python scripts/make_figures.py  (needs results/results.json)"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import _path  # noqa: F401
from sca.concepts import PERIODS, REGISTRY, Evaluator, Scope
from sca.semantic_layer import SemanticLayer
from sca.warehouse import connect

out = _path.ROOT / "paper" / "figures"
res = json.load(open(_path.ROOT / "results" / "results.json"))
ev = Evaluator(connect(_path.DB)); layer = SemanticLayer.load()
rev = REGISTRY["revenue"]; s = Scope("Mumbai", *PERIODS["last_month"])
vals = sorted((ev.value(rev, i, s) / 1e5, i) for i in rev.interpretations())
truth_i, naive_i = layer.get("revenue").choices, rev.naive

fig, ax = plt.subplots(figsize=(3.4, 2.5))
ax.scatter(range(len(vals)), [v for v, _ in vals], s=14, color="0.6", label="other readings")
for k, (v, i) in enumerate(vals):
    if i == truth_i: ax.scatter(k, v, s=40, color="tab:green", zorder=3, label="committed definition")
    if i == naive_i: ax.scatter(k, v, s=40, color="tab:red", marker="s", zorder=3, label="naive default")
ax.set_xlabel("interpretations (sorted)"); ax.set_ylabel("Mumbai revenue, Sept (Rs lakh)")
ax.legend(fontsize=6, frameon=False); fig.tight_layout(); fig.savefig(out / "spread.pdf"); plt.close(fig)

e2 = res["E2_partial_coverage"]; ks = sorted(int(k) for k in e2)
fig, ax = plt.subplots(figsize=(3.4, 2.3))
ax.plot(ks, [e2[str(k)]["context_silent_error"] for k in ks], "o-", color="tab:red", label="context agent")
ax.plot(ks, [e2[str(k)]["divergence_silent_error"] for k in ks], "s-", color="tab:blue", label="divergence-aware ($\\tau$=0.05)")
ax.set_xlabel("concepts covered by semantic layer (of 4)"); ax.set_ylabel("silent-error rate")
ax.set_xticks(ks); ax.legend(fontsize=6, frameon=False); fig.tight_layout(); fig.savefig(out / "coverage.pdf"); plt.close(fig)

e1 = res["E1_policies"]; taus = [0.01, 0.05, 0.1, 0.25, 0.5, 1.0]
fig, ax = plt.subplots(figsize=(3.4, 2.3))
ax.plot(taus, [e1[f"divergence_flag_only_tau{t:g}"]["silent_error_rate"] for t in taus], "o-", label="silent-error rate")
ax.plot(taus, [e1[f"divergence_flag_only_tau{t:g}"]["flag_rate"] for t in taus], "s--", label="flag rate")
ax.set_xscale("log"); ax.set_xlabel("threshold $\\tau$ on IDI"); ax.legend(fontsize=6, frameon=False)
fig.tight_layout(); fig.savefig(out / "tau.pdf"); plt.close(fig)
print("figures written to", out)

# ---- combined two-panel figure used in the 4-page paper ----
fig, (a1, a2) = plt.subplots(1, 2, figsize=(3.4, 1.2))
a1.scatter(range(len(vals)), [v for v, _ in vals], s=7, color="0.6")
for k, (v, i) in enumerate(vals):
    if i == truth_i: a1.scatter(k, v, s=22, color="tab:green", zorder=3, label="committed")
    if i == naive_i: a1.scatter(k, v, s=22, color="tab:red", marker="s", zorder=3, label="naive default")
a1.set_xlabel("(a) 24 readings, sorted", fontsize=6); a1.set_ylabel("Revenue (Rs lakh)", fontsize=6)
a1.legend(fontsize=5, frameon=False, loc="upper left"); a1.tick_params(labelsize=5)
a2.plot(ks, [e2[str(k)]["context_silent_error"] for k in ks], "o-", ms=3, color="tab:red", label="context agent")
a2.plot(ks, [e2[str(k)]["divergence_silent_error"] for k in ks], "s-", ms=3, color="tab:blue", label="divergence-aware")
a2.set_xlabel("(b) concepts covered (of 4)", fontsize=6); a2.set_ylabel("silent-error rate", fontsize=6)
a2.set_xticks(ks); a2.legend(fontsize=5, frameon=False); a2.tick_params(labelsize=5)
fig.tight_layout(pad=0.4); fig.savefig(out / "evidence.pdf"); plt.close(fig)
