"""Class demo (about 12 min):  python scripts/run_demo.py [--pause]
Six acts; --pause waits for Enter between acts. No API key needed."""
import argparse

import _path  # noqa: F401
from sca.agents import ContextAgent, DivergenceAwareAgent, NaiveAgent, Question
from sca.concepts import PERIODS, REGISTRY, Evaluator, Scope
from sca.divergence import interpretation_spread
from sca.semantic_layer import SemanticLayer, Steward
from sca.warehouse import connect

ap = argparse.ArgumentParser(); ap.add_argument("--pause", action="store_true"); args = ap.parse_args()


def act(title):
    if args.pause:
        input("\n[Enter] ")
    print("\n" + "=" * 78 + f"\n{title}\n" + "=" * 78)


def inr(x):
    s = f"{abs(x):.0f}"
    if len(s) > 3:
        head, tail, g = s[:-3], s[-3:], []
        while len(head) > 2:
            g.insert(0, head[-2:]); head = head[:-2]
        if head: g.insert(0, head)
        s = ",".join(g + [tail])
    return "Rs " + s


def show(c, v):
    return inr(v) if c.unit == "INR" else (f"{v:,.0f}" if c.unit == "orders" else f"{v:.2f}%")


con = connect(_path.DB); ev = Evaluator(con); layer = SemanticLayer.load()
MUM_M = Scope("Mumbai", *PERIODS["last_month"])

act("ACT 1 - What the tutorial's agent finds: why did Mumbai orders drop last week?")
for label, (a, b) in {"prior week": PERIODS["prior_week"], "last week ": PERIODS["last_week"]}.items():
    r = con.execute(f"""SELECT COUNT(*), SUM((status='delivered')::INT),
        SUM((cancel_reason='no_rider_available')::INT), SUM((cancel_reason='restaurant_closed')::INT)
        FROM orders o JOIN restaurants rs USING (restaurant_id) JOIN cities c ON c.city_id=rs.city_id
        WHERE c.city_name='Mumbai' AND order_ts >= TIMESTAMP '{a}' AND order_ts < TIMESTAMP '{b}' + INTERVAL 1 DAY""").fetchone()
    print(f"  {label}: placed={r[0]:,}  delivered={r[1]:,}  cancelled(no_rider)={r[2]:,}  cancelled(restaurant_closed)={r[3]:,}")
print("  -> Placement barely moved; deliveries fell because riders were unavailable. SQL access suffices here.")

act("ACT 2 - Same agent, four business metrics, Mumbai last month: right or wrong?")
print(f"  {'metric':12s} {'naive agent':>16s} {'committed truth':>16s}  verdict")
naive = NaiveAgent()
for name, c in REGISTRY.items():
    q = Question(name, name, MUM_M, "last_month", "", ev.value(c, layer.get(name).choices, MUM_M))
    a = naive.answer(q, ev)
    ok = abs(a.value - q.truth) < 1e-6
    print(f"  {name:12s} {show(c, a.value):>16s} {show(c, q.truth):>16s}  {'OK' if ok else 'SILENTLY WRONG'}")
print("  -> The SQL always ran. What was missing was the definition (cf. the tutorial's revenue gap).")

act("ACT 3 - Interpretation divergence: 24 defensible readings of 'revenue' (Mumbai, Sept)")
rev = REGISTRY["revenue"]; sp = interpretation_spread(ev, rev, MUM_M)
truth_i, naive_i = layer.get("revenue").choices, rev.naive
rows = sorted(((ev.value(rev, i, MUM_M), i) for i in rev.interpretations()), key=lambda t: t[0])
keep = {k for k in range(0, len(rows), 3)} | {k for k, (_, i) in enumerate(rows) if i in (truth_i, naive_i)}
for k in sorted(keep):
    v, i = rows[k]
    tag = " <- committed" if i == truth_i else (" <- naive" if i == naive_i else "")
    print(f"  {inr(v):>14s}  {i['status'][:3]}/{i['tax'][:3]}/{i['discount'][:5]}/{i['refunds'][:6]}{tag}")
print(f"  range {inr(sp.lo)} .. {inr(sp.hi)}   IDI = {sp.idi:.3f}   (every 3rd of 24 readings, plus committed and naive)")
print(f"  committed = {inr(ev.value(rev, truth_i, MUM_M))}, naive = {inr(ev.value(rev, naive_i, MUM_M))}")

act("ACT 4 - Semantic contract: a committed, versioned, hashed definition")
d = layer.get("revenue")
print(f"  revenue v{d.version}  hash={d.hash}\n  {d.description}\n  choices={d.choices}")
a = ContextAgent(layer).answer(Question("r", "revenue", MUM_M, "last_month", "", 0), ev)
print(f"  context agent answer = {inr(a.value)}   contract={a.contract}")

act("ACT 5 - No semantic layer at all: the divergence-aware agent escalates to a Steward")
st = Steward(layer)
agent = DivergenceAwareAgent(SemanticLayer({}), st, tau=0.05)
for city in ["Mumbai", "Delhi", "Pune"]:
    s = Scope(city, *PERIODS["last_month"])
    q = Question("q", "revenue", s, "last_month", "", 0)
    r = agent.answer(q, ev)
    idi = f"{r.idi:.3f}" if r.idi is not None else "  n/a (commitment reused)"
    print(f"  {city:10s} IDI={idi} flagged={r.flagged} source={r.source:14s} value={inr(r.value)}")
print(f"  steward calls for 3 questions: {st.calls}  (commitment is remembered after the first escalation)")

act("ACT 6 - Definition drift: finance changes revenue to 'before promo' (v2)")
v2 = layer.bump("revenue", {"discount": "before_promo"}, "Promos now merchant-funded.")
cached = [ContextAgent(layer).answer(Question("q", "revenue", Scope(c, *PERIODS["last_month"]), "last_month", "", 0), ev)
          for c in ["Mumbai", "Delhi"]]
for c, a in zip(["Mumbai", "Delhi"], cached):
    new = ev.value(rev, v2.get("revenue").choices, Scope(c, *PERIODS["last_month"]))
    print(f"  cached {c:7s} {inr(a.value)} contract still valid? {v2.validate(a.contract)}  -> under v2: {inr(new)} ({(new-a.value)/a.value:+.1%})")
print("  Without a contract reference these cached numbers look fine forever.")
