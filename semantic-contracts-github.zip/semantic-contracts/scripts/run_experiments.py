"""Reproduce every number in the paper:  python scripts/run_experiments.py
Writes results/results.json and results/summary.md."""
import itertools
import json

import _path  # noqa: F401
from sca.agents import ContextAgent, DivergenceAwareAgent, NaiveAgent
from sca.benchmark import build_benchmark, is_correct, summarise
from sca.concepts import REGISTRY, Evaluator, Scope
from sca.divergence import interpretation_spread, oat_interpretations, oat_spread
from sca.semantic_layer import SemanticLayer, Steward
from sca.warehouse import connect

TAUS = [0.01, 0.05, 0.10, 0.25, 0.50, 1.00]

con = connect(_path.DB)
ev = Evaluator(con)
full = SemanticLayer.load()
qs = build_benchmark(ev, full)
out = {"n_questions": len(qs), "interpretations": {c: len(REGISTRY[c].interpretations()) for c in REGISTRY}}


def run(agent):
    return [agent.answer(q, ev) for q in qs]


# ---------- E0: how ambiguous is each concept? ----------
e0 = {}
for cname, c in REGISTRY.items():
    idis, naive_err = [], []
    for q in (q for q in qs if q.concept == cname):
        idis.append(interpretation_spread(ev, c, q.scope).idi)
        naive_err.append(abs(ev.value(c, c.naive, q.scope) - q.truth) / abs(q.truth))
    e0[cname] = {"mean_idi": sum(idis) / len(idis), "min_idi": min(idis), "max_idi": max(idis),
                 "naive_mean_abs_rel_error": sum(naive_err) / len(naive_err),
                 "naive_is_canonical": c.naive == full.get(cname).choices}
out["E0_concept_ambiguity"] = e0

# ---------- E1: policies on the full benchmark, no semantic layer coverage for divergence agents ----------
e1 = {}
e1["naive"] = summarise(run(NaiveAgent()), qs)
e1["context_full"] = summarise(run(ContextAgent(full)), qs)
empty = SemanticLayer({})
for tau in TAUS:
    e1[f"divergence_flag_only_tau{tau:g}"] = summarise(run(DivergenceAwareAgent(empty, None, tau)), qs)
    st = Steward(full)
    s = summarise(run(DivergenceAwareAgent(empty, st, tau)), qs)
    s["steward_calls"] = st.calls
    e1[f"divergence_steward_tau{tau:g}"] = s
out["E1_policies"] = e1

# ---------- E2: partial semantic-layer coverage ----------
names = list(REGISTRY)
e2 = {}
for k in range(len(names) + 1):
    ctx_silent, div_silent, div_calls, ctx_acc, div_acc = [], [], [], [], []
    for covered in itertools.combinations(names, k):
        layer = full.restrict(covered)
        a = summarise(run(ContextAgent(layer)), qs)
        st = Steward(full)
        b = summarise(run(DivergenceAwareAgent(layer, st, 0.05)), qs)
        ctx_silent.append(a["silent_error_rate"]); ctx_acc.append(a["accuracy"])
        div_silent.append(b["silent_error_rate"]); div_acc.append(b["accuracy"]); div_calls.append(st.calls)
    m = lambda xs: sum(xs) / len(xs)
    e2[str(k)] = {"context_silent_error": m(ctx_silent), "context_accuracy": m(ctx_acc),
                  "divergence_silent_error": m(div_silent), "divergence_accuracy": m(div_acc),
                  "divergence_steward_calls": m(div_calls), "n_subsets": len(ctx_silent)}
out["E2_partial_coverage"] = e2

# ---------- E3: definition drift ----------
v2 = full.bump("revenue", {"discount": "before_promo"},
               "Promotions are now merchant-funded; platform revenue is recognised before promo discount.")
agent = ContextAgent(full)
rows = []
for q in (q for q in qs if q.concept == "revenue" and q.period == "last_month"):
    a = agent.answer(q, ev)
    new_val = ev.value(REGISTRY["revenue"], v2.get("revenue").choices, q.scope)
    rows.append({"city": q.scope.city, "cached_value": a.value, "value_under_v2": new_val,
                 "relative_change": (new_val - a.value) / a.value,
                 "stale_detected_with_contract": not v2.validate(a.contract),
                 "stale_detected_without_contract": False})
out["E3_drift"] = {"v1_hash": full.get("revenue").hash, "v2_hash": v2.get("revenue").hash, "rows": rows,
                   "detected_with_contract": sum(r["stale_detected_with_contract"] for r in rows),
                   "detected_without_contract": 0, "n": len(rows),
                   "mean_abs_relative_change": sum(abs(r["relative_change"]) for r in rows) / len(rows)}


# ---------- E4: cheap one-at-a-time (OAT) estimator of the interpretation range ----------
e4 = {"evaluations_full": {c: len(REGISTRY[c].interpretations()) for c in REGISTRY},
      "evaluations_oat": {c: len(oat_interpretations(REGISTRY[c])) for c in REGISTRY}}
ratios, rows4 = [], []
for q in qs:
    c = REGISTRY[q.concept]
    f, o = interpretation_spread(ev, c, q.scope), oat_spread(ev, c, q.scope)
    ratios.append((o.hi - o.lo) / (f.hi - f.lo))
    rows4.append((f.idi, o.idi))
e4["mean_range_ratio"] = sum(ratios) / len(ratios)
e4["min_range_ratio"] = min(ratios)
e4["flag_agreement"] = {}
for tau in (0.05, 0.10, 0.25):
    agree = sum((f > tau) == (o > tau) for f, o in rows4) / len(rows4)
    missed = sum((f > tau) and not (o > tau) for f, o in rows4)
    e4["flag_agreement"][f"tau{tau:g}"] = {"agreement": agree, "missed_by_oat": missed}
out["E4_oat"] = e4

# ---------- Mumbai headline (the tutorial's example) ----------
mum = Scope("Mumbai", "2026-09-01", "2026-09-30")
rev = REGISTRY["revenue"]
sp = interpretation_spread(ev, rev, mum)
out["mumbai_september_revenue"] = {
    "truth": ev.value(rev, full.get("revenue").choices, mum),
    "naive": ev.value(rev, rev.naive, mum),
    "idi": sp.idi, "lo": sp.lo, "hi": sp.hi, "n_interpretations": len(sp.values), "n_distinct": sp.n_distinct}

json.dump(out, open(_path.ROOT / "results" / "results.json", "w"), indent=2)

# ---------- markdown summary ----------
L = ["# Experiment summary", f"\n{len(qs)} questions; interpretation-set sizes: {out['interpretations']}\n",
     "## E0 concept ambiguity\n", "| concept | mean IDI | naive mean abs rel err | naive == committed |", "|---|---|---|---|"]
for c, r in e0.items():
    L.append(f"| {c} | {r['mean_idi']:.3f} | {r['naive_mean_abs_rel_error']:.3f} | {r['naive_is_canonical']} |")
L += ["\n## E1 policies\n", "| policy | accuracy | flag rate | silent error | steward calls |", "|---|---|---|---|---|"]
for p, r in e1.items():
    L.append(f"| {p} | {r['accuracy']:.3f} | {r['flag_rate']:.3f} | {r['silent_error_rate']:.3f} | {r.get('steward_calls','-')} |")
L += ["\n## E2 partial coverage (tau=0.05)\n", "| concepts covered | context silent err | divergence silent err | steward calls |", "|---|---|---|---|"]
for k, r in e2.items():
    L.append(f"| {k}/4 | {r['context_silent_error']:.3f} | {r['divergence_silent_error']:.3f} | {r['divergence_steward_calls']:.2f} |")
e4s = out["E4_oat"]
L += ["\n## E4 OAT estimator\n", f"evaluations full={e4s['evaluations_full']} oat={e4s['evaluations_oat']}; "
      f"mean range ratio={e4s['mean_range_ratio']:.3f} (min {e4s['min_range_ratio']:.3f}); flag agreement={e4s['flag_agreement']}"]
d = out["E3_drift"]
L += ["\n## E3 drift\n", f"revenue v1 `{d['v1_hash']}` -> v2 `{d['v2_hash']}`; stale answers detected with contracts: "
      f"{d['detected_with_contract']}/{d['n']}, without: {d['detected_without_contract']}/{d['n']}; "
      f"mean |change| = {d['mean_abs_relative_change']:.3%}"]
(_path.ROOT / "results" / "summary.md").write_text("\n".join(L) + "\n")
print("\n".join(L))
