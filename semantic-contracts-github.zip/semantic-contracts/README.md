# Semantic Contracts for Data Agents

Class demo + research prototype for a **blue-sky paper**: *metric definitions should be
commitments (versioned, hashed "semantic contracts"), and data agents should measure
definitional ambiguity instead of guessing.*

Inspired by a tutorial on data agents in which a SQL agent found the right tables and joins
but reported revenue ~7% off, because it never learned the business definition of "revenue".

## Quickstart (2 minutes, no API key)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python scripts/build_warehouse.py        # seeded synthetic DuckDB, ~170k orders
python scripts/run_demo.py --pause       # the 6-act class demo
python scripts/run_experiments.py        # reproduces every number in the paper
python scripts/make_figures.py           # paper/figures/*.pdf
pytest -q tests                          # 9 tests (incl. numerical checks of Props 2-4)
```

## Classroom script (~12 min, `run_demo.py --pause`)
| Act | Talking point |
|---|---|
| 1 | A SQL agent can explain *why* Mumbai orders dropped (riders unavailable). |
| 2 | Same agent, 4 metrics: 3 of 4 are silently wrong. SQL ran fine every time. |
| 3 | 24 defensible readings of "revenue" span Rs 22.99L to 29.85L. Define the **IDI**. |
| 4 | A semantic contract = (metric, version, hash). Context agent is exact. |
| 5 | No semantic layer? Agent measures IDI, escalates to a **Steward**, remembers the commitment. |
| 6 | Finance changes the definition. Contracts detect stale answers; plain numbers cannot. |

Discussion prompts: Is the interpretation set ever complete? Who should the steward be?
What should an agent do when two departments disagree?

## Layout
```
sca/            concepts.py (axes + SQL), divergence.py (IDI), semantic_layer.py (contracts, Steward),
                agents.py (naive / context / divergence-aware), benchmark.py, warehouse.py (data)
semantic/       metrics.yaml  <- the committed definitions (plays the role of dbt/MetricFlow)
scripts/        build_warehouse, run_demo, run_experiments, make_figures, llm_agent (optional, live LLM)
tests/          invariants + hand-computed revenue check
paper/          main.tex (+ figures); main.pdf compiled draft
results/        results.json, summary.md (generated)
```

## Headline results (seed 7; see results/summary.md)
- Naive default agent: **75% silently wrong** (accuracy 0.25) on 48 questions.
- IDI-based escalation with a steward: **0 silent errors**, accuracy 1.0 with 4 clarifications.
- Partial semantic-layer coverage 0 to 4 of 4 concepts: context agent silent error 0.75 to 0, divergence-aware stays 0.
- Definition drift: contracts flag 6/6 stale answers; plain numbers 0/6.
- One-at-a-time (OAT) estimator: 6 instead of 24 evaluations for revenue; 91% of the full range on average; no false ambiguity alarms (Prop. 3).

## Honest limitations (also in the paper)
- Agents in the experiments are **simulated policies**, not LLMs. They demonstrate the mechanism, not LLM behaviour.
- `scripts/llm_agent.py` runs the same ideas with Claude in the loop (`ANTHROPIC_API_KEY`, model via `ANTHROPIC_MODEL`,
  default `claude-sonnet-5-5`). It is untested against the live API and was **not** used for the paper's numbers.
  A good extension for students: run it on the 48 questions and compare with the simulation.
- Data are synthetic. The committed definition is inside the interpretation set by construction.
- IDI is a triage signal: it says "this is ambiguous", not "your default is wrong".

## Paper (AAMAS 2027 Blue Sky Ideas Track, 4 pages)
Title: *Semantic Contracts for LLM Data Agents: Metric Definitions Are Committed and Ambiguity Is Measured in Multiagent Text-to-SQL Analytics*
- `paper/main.tex` uses the official AAMAS 2027 template (`aamas.cls`, `by.pdf`, `ACM-Reference-Format.bst`, structure of
  `AAMAS_2027_sample.tex`) with `\documentclass[sigconf,anonymous]{aamas}` and `\submissionType{Blue Sky Ideas Track}`.
  `paper/main.pdf` is the compiled 4-page PDF (references included).
- `paper/Semantic_Contracts_Paper.docx`: Word version with native equations, generated from `main.tex` by
  `python paper/build_docx.py` (needs `pandoc`). Edit `main.tex` and regenerate; `main.tex` is the master.
- Build: `cd paper && pdflatex main && bibtex main && pdflatex main && pdflatex main`.
- Before submitting: set `\acmSubmissionID{...}` (OpenReview number) and the author block; for the camera-ready switch to
  `\documentclass[sigconf]{aamas}`. **Double-blind:** the supplementary link in the Conclusion names a personal GitHub account;
  replace it with an anonymised repository link for the review version. Verify every entry in `paper/references.bib`
  (author lists are abbreviated with "and others" and should be completed) and add the tutorial URL.

## Mapping paper to code
| Paper | Code |
|---|---|
| Eq. (1)-(2) interpretation set, value | `sca/concepts.py` (`Concept.interpretations`, `Evaluator`) |
| Eq. (5) IDI | `sca/divergence.py::interpretation_spread` |
| Eq. (8) OAT neighbourhood | `sca/divergence.py::oat_interpretations` |
| Eq. (6) contract hash, Prop. 6 | `sca/semantic_layer.py` (`Definition.hash`, `SemanticLayer.validate`) |
| Alg. 1 Answer | `sca/agents.py::DivergenceAwareAgent` |
| Alg. 2 ValidateAndRefresh | `SemanticLayer.validate` + `scripts/run_experiments.py` (E3) |
| Alg. 3 DiscoverAxes | not implemented (proposed) |
| Props 2-4 | `tests/test_core.py` (numerical checks) |

## Publish to GitHub
```bash
git init && git add . && git commit -m "Semantic contracts demo + paper draft"
git branch -M main && git remote add origin <your-repo-url> && git push -u origin main
```
