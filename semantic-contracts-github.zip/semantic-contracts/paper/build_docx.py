"""Build a Word version of main.tex:  python paper/build_docx.py   (needs pandoc + pdftoppm)
main.tex is the master; this script rewrites it into pandoc-friendly LaTeX (numbering resolved,
theorem/algorithm environments flattened, PDF figures swapped for PNG) and converts it to .docx
with native Word equations."""
import re, subprocess, pathlib

HERE = pathlib.Path(__file__).resolve().parent
src = (HERE / "main.tex").read_text()

title = re.search(r"\\title(?:\[[^\]]*\])?\{(.*?)\}\n", src).group(1).replace("\\\\", " ").strip()
abstract = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", src, re.S).group(1).strip()
keywords = re.search(r"\\keywords\{(.*?)\}", src).group(1)
body = src[src.index("\\section{Introduction}"):src.index("\\bibliographystyle")]
body = re.sub(r"(?m)^%.*$\n?", "", body)
body = re.sub(r"\\Description\{.*?\}\n", "", body, flags=re.S)
body = body.replace("\\balance", "").replace("\\addlinespace", "")

body = body.replace("\\begin{table*}[t]", "\\begin{table}").replace("\\end{table*}", "\\end{table}")

# ---------- numbering ----------
labels, sec, cnt, glob = {}, 0, {}, {"eq": 0, "tab": 0, "fig": 0, "alg": 0}
tok = re.compile(r"\\section\{|\\begin\{(definition|proposition)\}|\\begin\{(equation|table|figure)\}|(\\refstepcounter\{algorithm\})")
for m in tok.finditer(body):
    end = body.find("\\end{", m.end()) if m.group(2) else None
    if m.group(0).startswith("\\section"):
        sec += 1; cnt = {}
        nxt = re.search(r"\\label\{([^}]*)\}", body[m.end():m.end() + 200])
        continue
    kind = m.group(1) or m.group(2) or "algorithm"
    seg = body[m.end(): m.end() + 4000]
    lab = re.search(r"\\label\{([^}]*)\}", seg)
    if kind in ("definition", "proposition"):
        cnt[kind] = cnt.get(kind, 0) + 1; num = f"{sec}.{cnt[kind]}"
    else:
        key = {"equation": "eq", "table": "tab", "figure": "fig", "algorithm": "alg"}[kind]
        glob[key] += 1; num = str(glob[key])
    if lab:
        labels[lab.group(1)] = num
# section labels
secn = 0
for m in re.finditer(r"\\section\{[^}]*\}(\\label\{([^}]*)\})?", body):
    secn += 1
    if m.group(2): labels[m.group(2)] = str(secn)

# ---------- environments ----------
counter = {"table": 0, "figure": 0, "algorithm": 0, "equation": 0}

def cap_block(kind, word):
    def f(m):
        counter[kind] += 1
        t = m.group(0)
        t = re.sub(r"\\caption\{", f"\\\\caption{{{word} {counter[kind]}. ", t, count=1)
        return t
    return f

body = re.sub(r"\\begin\{table\}.*?\\end\{table\}", cap_block("table", "Table"), body, flags=re.S)
body = re.sub(r"\\begin\{figure\}.*?\\end\{figure\}", cap_block("figure", "Figure"), body, flags=re.S)
body = re.sub(r"\[width=[^\]]*\]\{figures/(\w+)\.pdf\}", r"[width=3in]{figures/\1.png}", body)

UNI = {r"\gets": "←", r"\bot": "⊥", r"\ne": "≠", r"\varphi": "φ", r"\in": "∈", r"\epsilon_0": "ε0", r"\epsilon": "ε", r"\tau": "τ", r"\nu": "ν",
       r"\kappa": "κ", r"\ell": "ℓ", r"\star": "*", r"\Sigma": "Σ", r"\delta": "δ", r"\IDI": "IDI", r"\med": "med",
       r"\min": "min", r"\max": "max", r"\mathcal{I}": "I", r"\mathcal{N}": "N", r"\mathcal{C}": "C", r"\mathcal{Q}": "Q",
       r"\setminus": "\\", r"\leftarrow": "←", r"\ ": " ", r"\,": " ", r"\;": " ", r"\!": ""}

def plain(t):
    t = re.sub(r"\\textsc\{([^}]*)\}", r"\1", t)
    t = re.sub(r"\\textbf\{([^}]*)\}", r"\1", t)
    t = re.sub(r"\\COMMENT\{(.*)\}", r"▹ \1", t)
    t = t.replace("\\hfill", "   ")
    t = re.sub(r"\\ref\{([^}]*)\}", lambda m: labels.get(m.group(1), "?"), t)
    t = re.sub(r"\\eqref\{[^}]*\}", lambda m: "(" + labels.get(m.group(0)[7:-1], "?") + ")", t)
    t = t.replace("\\{", "⟦").replace("\\}", "⟧")
    for k in sorted(UNI, key=len, reverse=True):
        t = t.replace(k, UNI[k])
    t = re.sub(r"\\[A-Za-z]+", "", t)
    t = t.replace("$", "").replace("{", "").replace("}", "").replace("~", " ")
    t = t.replace("⟦", "{").replace("⟧", "}")
    return re.sub(r"[ ]{2,}", "  ", t).strip()

def alg_lines(inner):
    lines, depth, k = [], 0, 0
    for raw in inner.strip().splitlines():
        raw = raw.strip()
        if not raw: continue
        cmd = re.match(r"\\([A-Z]+)(.*)", raw)
        c, rest = cmd.group(1), cmd.group(2).strip()
        if c in ("REQUIRE", "ENSURE"):
            lines.append(("Input: " if c == "REQUIRE" else "Output: ") + plain(rest)); continue
        if c in ("ELSE", "ENDIF", "ENDFOR"): depth -= 1
        if c == "ELSE": text = "else"
        elif c == "ENDIF": text = "end if"
        elif c == "ENDFOR": text = "end for"
        elif c == "IF":
            cond = re.match(r"\{(.*)\}(.*)", rest); text = "if " + plain(cond.group(1)) + " then"
        elif c == "FOR":
            cond = re.match(r"\{(.*)\}(.*)", rest); text = "for " + plain(cond.group(1)) + " do"
        elif c == "RETURN": text = "return " + plain(rest)
        else: text = plain(rest)
        k += 1
        lines.append(f"{k:2d}. " + "    " * max(depth, 0) + text)
        if c in ("IF", "FOR", "ELSE"): depth += 1
    return lines

def alg_fig(m):
    out = []
    pat = r"\\refstepcounter\{algorithm\}\\label\{[^}]*\}\\textbf\{Algorithm \\thealgorithm\.\}\s*(.*?)\n\\begin\{algorithmic\}(?:\[1\])?(.*?)\\end\{algorithmic\}"
    for am in re.finditer(pat, m.group(0), re.S):
        counter["algorithm"] += 1
        title = re.sub(r"\\textsc\{([^}]*)\}", r"\1", am.group(1)).strip()
        out.append("\\par\\textbf{Algorithm %d. %s}\n\\begin{verbatim}\n%s\n\\end{verbatim}\n" % (counter["algorithm"], title, "\n".join(alg_lines(am.group(2)))))
    return "\n".join(out)

body = re.sub(r"\\begin\{figure\*\}.*?\\end\{figure\*\}", alg_fig, body, flags=re.S)

# theorem-like environments
def thm(name, word):
    def f(m):
        n = labels.get(m.group(3) or "", "")
        t = f" ({m.group(2)})" if m.group(2) else ""
        return f"\\par\\textbf{{{word} {n}{t}.}} "
    return f
for env, word in (("definition", "Definition"), ("proposition", "Proposition")):
    cnts = {}
    # resolve numbers in order of appearance within section: reuse label map when labelled, else compute
    pat = re.compile(r"\\begin\{%s\}(\[(.*?)\])?(?:\\label\{([^}]*)\})?" % env)
    sec2, c2, out, pos = 0, 0, [], 0
    for m in pat.finditer(body):
        pass
    # sequential numbering by section
    parts = re.split(r"(\\section\{)", body)
    res, sec_i, k = [], 0, 0
    for p in parts:
        if p == "\\section{": sec_i += 1; k = 0; res.append(p); continue
        def rep(m):
            global k
            return m.group(0)
        out_p, last = "", 0
        for m in pat.finditer(p):
            k += 1
            t = f" ({m.group(2)})" if m.group(2) else ""
            out_p += p[last:m.start()] + f"\\par\\textbf{{{word} {sec_i}.{k}{t}.}} "
            last = m.end()
        out_p += p[last:]
        res.append(out_p)
    body = "".join(res)
    body = body.replace("\\end{%s}" % env, "\\par")
body = re.sub(r"\\begin\{proof\}", r"\\par\\textit{Proof.} ", body)
body = body.replace("\\end{proof}", " $\\square$\\par").replace("\\qedhere", "")

# equations: number and flatten
def eq(m):
    counter["equation"] += 1
    t = m.group(1)
    t = re.sub(r"\\label\{[^}]*\}", "", t).replace("{split}", "{aligned}").replace("\\textstyle", "")
    t = t.replace("\\IDI", "\\operatorname{IDI}").replace("\\med", "\\operatorname{med}")
    t = t.replace("\\!", " ").replace("\\mathbb{1}", "\\mathbf{1}")
    n = counter["equation"]
    if "aligned" in t:
        inner = re.search(r"\\begin\{aligned\}(.*?)\\end\{aligned\}", t, re.S).group(1).replace("&", "")
        rows = [r.strip() for r in inner.split("\\\\") if r.strip()]
        merged = []
        for r in rows:
            if merged and r.startswith("\\qquad"): merged[-1] += " " + r
            else: merged.append(r)
        return "\n\n".join("\\[ %s%s \\]" % (r, " \\qquad (%d)" % n if i == len(merged) - 1 else "") for i, r in enumerate(merged))
    return "\\[ %s \\qquad (%d) \\]" % (t.strip(), n)
body = re.sub(r"\\begin\{equation\}(.*?)\\end\{equation\}", eq, body, flags=re.S)
body = body.replace("\\IDI", "\\operatorname{IDI}").replace("\\med", "\\operatorname{med}")

# references
for k, u in {"I": "ℐ", "N": "𝒩", "L": "ℒ", "C": "𝒞", "Q": "𝒬", "A": "𝒜"}.items():
    body = body.replace("\\mathcal{%s}" % k, "{%s}" % u)
body = body.replace("\\mathbb{R}", "{ℝ}").replace("\\mathbb{N}", "{ℕ}").replace("\\mathbb{1}", "{𝟙}").replace("\\mathrm{", "\\operatorname{")
body = re.sub(r"\\eqref\{([^}]*)\}", lambda m: "(%s)" % labels.get(m.group(1), "?"), body)
body = re.sub(r"\\ref\{([^}]*)\}", lambda m: labels.get(m.group(1), "?"), body)
body = body.replace("\\itemsep0pt", "").replace("\\hfill", " ")
body = re.sub(r"\\label\{[^}]*\}", "", body)

doc = ("\\documentclass{article}\\usepackage{amsmath}\n\\title{%s}\n\\author{Anonymous Author(s)}\n\\date{}\n\\begin{document}\n\\maketitle\n"
       "\\begin{abstract}\n%s\n\\end{abstract}\n\\par\\textbf{Keywords:} %s\n%s\n\\section*{References}\n\\end{document}\n") % (title, abstract, keywords, body)
(HERE / "_docx_src.tex").write_text(doc)
cmd = ["pandoc", "_docx_src.tex", "-f", "latex", "-t", "docx", "--citeproc", "--bibliography", "references.bib",
       "--number-sections", "-o", "Semantic_Contracts_Paper.docx"]
if (HERE / "acm.csl").exists(): cmd += ["--csl", "acm.csl"]
subprocess.run(cmd, cwd=HERE, check=True)
print("wrote", HERE / "Semantic_Contracts_Paper.docx")
