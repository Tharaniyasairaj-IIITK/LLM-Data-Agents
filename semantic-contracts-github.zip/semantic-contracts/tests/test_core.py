import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import pytest
from sca.warehouse import build, connect
from sca.concepts import REGISTRY, Evaluator, Scope, PERIODS
from sca.divergence import interpretation_spread
from sca.semantic_layer import SemanticLayer, Steward
from sca.agents import NaiveAgent, ContextAgent, DivergenceAwareAgent
from sca.benchmark import build_benchmark, is_correct


@pytest.fixture(scope="module")
def env(tmp_path_factory):
    p = build(tmp_path_factory.mktemp("w") / "w.duckdb", seed=3, n_orders=20_000)
    ev = Evaluator(connect(p))
    layer = SemanticLayer.load()
    return ev, layer, build_benchmark(ev, layer)


def test_yaml_choices_are_valid_axis_values():
    layer = SemanticLayer.load()
    for name, c in REGISTRY.items():
        d = layer.get(name)
        assert set(d.choices) == set(c.axes)
        assert all(d.choices[k] in c.axes[k] for k in c.axes)
        assert all(c.naive[k] in c.axes[k] for k in c.axes)


def test_committed_definition_is_in_interpretation_set(env):
    ev, layer, _ = env
    for name, c in REGISTRY.items():
        assert layer.get(name).choices in c.interpretations()


def test_revenue_matches_hand_computation(env):
    ev, layer, _ = env
    s = Scope("Mumbai", *PERIODS["last_month"])
    ref = ev.con.execute("""
        SELECT SUM(o.amount - o.promo_value - t.gst) FROM orders o
        JOIN restaurants rs USING (restaurant_id) JOIN cities c ON c.city_id = rs.city_id
        JOIN order_taxes t USING (order_id) LEFT JOIN refunds r USING (order_id)
        WHERE c.city_name='Mumbai' AND o.status='delivered' AND r.order_id IS NULL
          AND o.order_ts >= TIMESTAMP '2026-09-01' AND o.order_ts < TIMESTAMP '2026-10-01'""").fetchone()[0]
    assert ev.value(REGISTRY["revenue"], layer.get("revenue").choices, s) == pytest.approx(ref)


def test_naive_revenue_is_wrong_and_spread_positive(env):
    ev, layer, qs = env
    q = next(q for q in qs if q.concept == "revenue" and q.scope.city == "Mumbai" and q.period == "last_month")
    assert not is_correct(NaiveAgent().answer(q, ev), q)
    assert interpretation_spread(ev, REGISTRY["revenue"], q.scope).idi > 0.05


def test_context_agent_is_perfect_and_contract_backed(env):
    ev, layer, qs = env
    agent = ContextAgent(layer)
    for q in qs:
        a = agent.answer(q, ev)
        assert is_correct(a, q) and layer.validate(a.contract)


def test_divergence_agent_never_silently_wrong_at_low_tau(env):
    ev, layer, qs = env
    agent = DivergenceAwareAgent(SemanticLayer({}), Steward(layer), tau=0.01)
    for q in qs:
        a = agent.answer(q, ev)
        assert a.flagged or is_correct(a, q)


def test_contract_invalidated_by_definition_change(env):
    _, layer, _ = env
    ref = layer.get("revenue").ref
    v2 = layer.bump("revenue", {"discount": "before_promo"})
    assert layer.validate(ref) and not v2.validate(ref) and not v2.validate(None)


def test_proposition_error_bound_and_oat_lower_bound(env):
    from statistics import median
    from sca.divergence import oat_spread
    ev, layer, qs = env
    for q in qs:
        c = REGISTRY[q.concept]
        sp = interpretation_spread(ev, c, q.scope)
        for i in c.interpretations():
            assert abs(ev.value(c, i, q.scope) - q.truth) <= sp.idi * abs(sp.med) + 1e-9      # Prop. 1
        assert oat_spread(ev, c, q.scope).hi - oat_spread(ev, c, q.scope).lo <= sp.hi - sp.lo + 1e-9  # Prop. 3


def test_expected_loss_at_most_half_idi(env):
    import random
    ev, layer, qs = env
    rng = random.Random(0)
    for q in qs:
        c = REGISTRY[q.concept]
        sp = interpretation_spread(ev, c, q.scope)
        vals = list(sp.values)
        for _ in range(5):
            w = [rng.random() for _ in vals]; w = [x / sum(w) for x in w]
            L = min(sum(wj * abs(vj - a) for wj, vj in zip(w, vals)) for a in vals) / max(abs(sp.med), 1e-9)
            assert L <= sp.idi / 2 + 1e-9                                                      # Prop. 4
